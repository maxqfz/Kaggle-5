class Constants {
  static var x = 2
  static var y = 3
}