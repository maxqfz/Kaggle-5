package com.example.myproject;

class Fail {
  public static void main(String []args) {
    System.exit(1);
  }
}
