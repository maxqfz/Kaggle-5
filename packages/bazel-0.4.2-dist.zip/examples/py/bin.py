from examples.py import lib

print("Fib(5)=%d" % lib.Fib(5))
