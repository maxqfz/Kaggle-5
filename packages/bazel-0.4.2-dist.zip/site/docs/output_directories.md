---
layout: redirect
redirect: docs/output_directories.html
---
